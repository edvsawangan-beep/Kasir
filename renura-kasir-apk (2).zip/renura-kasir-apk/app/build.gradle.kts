plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "id.renura.kasir"
    compileSdk = 34
    defaultConfig { applicationId = "id.renura.kasir"; minSdk = 29; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

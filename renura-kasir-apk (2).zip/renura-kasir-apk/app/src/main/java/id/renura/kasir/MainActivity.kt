package id.renura.kasir

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.webkit.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var cb: ValueCallback<Array<Uri>>? = null
    private var camUri: Uri? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#4F46E5")
        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            allowFileAccess = true; javaScriptCanOpenWindowsAutomatically = true
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (r.url.scheme == "file") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (e: Exception) {}
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView, c: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                cb?.onReceiveValue(null); cb = c
                val cv = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "renura_${System.currentTimeMillis()}.jpg")
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                }
                camUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                val cam = Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, camUri)
                val pick = Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*")
                val ch = Intent.createChooser(pick, "Ambil / pilih foto").putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(cam))
                startActivityForResult(ch, 7)
                return true
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        if (Build.VERSION.SDK_INT >= 31) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        if (rc == 7) {
            val r: Array<Uri>? = if (res == RESULT_OK) (d?.data ?: camUri)?.let { arrayOf(it) } else null
            cb?.onReceiveValue(r); cb = null
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    inner class Bridge {
        private fun adapter() = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter

        @JavascriptInterface fun pairedPrinters(): String = try {
            val arr = JSONArray()
            adapter()?.bondedDevices?.forEach { arr.put(JSONObject().put("n", it.name ?: it.address).put("a", it.address)) }
            arr.toString()
        } catch (e: Exception) { "[]" }

        @JavascriptInterface fun printBytes(mac: String, b64: String): String = try {
            val a = adapter()
            val s = a.getRemoteDevice(mac).createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
            a.cancelDiscovery(); s.connect()
            val o = s.outputStream; val data = Base64.decode(b64, Base64.DEFAULT)
            var i = 0
            while (i < data.size) { val n = minOf(512, data.size - i); o.write(data, i, n); o.flush(); i += n; Thread.sleep(20) }
            Thread.sleep(600); s.close(); "ok"
        } catch (e: Exception) { e.message ?: "error" }

        @JavascriptInterface fun openBtSettings() = runOnUiThread { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }

        @JavascriptInterface fun shareImage(b64: String, name: String): String = try {
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name); put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Renura")
            }
            val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
            contentResolver.openOutputStream(u)!!.use { it.write(Base64.decode(b64, Base64.DEFAULT)) }
            val i = Intent(Intent.ACTION_SEND).setType("image/png").putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            runOnUiThread { startActivity(Intent.createChooser(i, "Kirim struk")) }
            "ok"
        } catch (e: Exception) { e.message ?: "error" }

        @JavascriptInterface fun saveFile(name: String, text: String, mime: String): String = try {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name); put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, "Download")
            }
            val u = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
            contentResolver.openOutputStream(u)!!.use { it.write(text.toByteArray()) }
            "ok"
        } catch (e: Exception) { e.message ?: "error" }
    }
}
